# NOTES

[+] kitty @ launch x tmux

```note
== Issue
> when launch instance of kitty and quit
> and we back to the terminal can't open > kitty @ launch again
> with error no listen on socket found at unix:/tmp/kitty-XXXXX

= Reproduce
> kill tmux-session quit kitty terminal
> and we can use kitty instance again
> almost annoying

= DONE
> dont use kitty stupid remote its not support tmux
> just replace image previewer using chafa when using tmux
> replace kitty to alacritty
```

<!-- ================================================================ -->

<hr>

[+] Browser Plugins

```note
== Plugins
> pywalfox
> simpletranslate
> vimiumc
> df youtube + adblock youtube + youtube ad auto-skiper
> darkreader
> awesome rss
> react developer
> vue developer
> redux dev tools
```

[+] Python Package

```note
== pyenv/pip
> flake8
> black
> isort
> pywal
> pywalfox
```

[+] Javascript Package

```note
== nvm/npm
browser-sync
nodemon
yarn
```

<!-- ================================================================ -->

<hr>

[+] crontab job

```note
== Format
┌───────────── minute (0 - 59)
│ ┌───────────── hour (0 - 23)
│ │ ┌───────────── day of month (1 - 31)
│ │ │ ┌───────────── month (1 - 12)
│ │ │ │ ┌───────────── day of week (0 - 6) (Sunday to Saturday,7 is also Sunday on some systems)
│ │ │ │ │
│ │ │ │ │
│ │ │ │ │
* * * * * command_to_execute

== Example
0 0 1,15 * * echo 'hello' >> /Users/shendypratama/tmp/test.txt

0 0 * * 1 echo 'hello' >> /Users/shendypratama/tmp/test.txt

== Manage
> backup data for certain datetime
```

<!-- ================================================================ -->
<hr>

[project]

```note
[-] port master stacking into yabai
```

<!-- ================================================================ -->
<hr>
